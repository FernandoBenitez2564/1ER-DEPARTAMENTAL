





describe ('Pruebas en el archivo pp.test.js', () => {

  test('debe ser true'   , () => {



    const mensaje = 'Hola mundo!';
  
  
    const mensaje2 = 'Hola mundo!'
  
    expect (mensaje ) .toBe( mensaje2 );
    
  })


});









